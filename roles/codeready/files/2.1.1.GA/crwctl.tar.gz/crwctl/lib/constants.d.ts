declare const DEFAULT_CHE_IMAGE = "registry.redhat.io/codeready-workspaces/server-rhel8:2.1-22";
declare const DEFAULT_CHE_OPERATOR_IMAGE = "registry.redhat.io/codeready-workspaces/crw-2-rhel8-operator:2.1-21";
export { DEFAULT_CHE_IMAGE, DEFAULT_CHE_OPERATOR_IMAGE };

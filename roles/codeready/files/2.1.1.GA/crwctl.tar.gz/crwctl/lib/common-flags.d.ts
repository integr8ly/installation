export declare const cheNamespace: import("@oclif/parser/lib/flags").IOptionFlag<string>;
export declare const cheDeployment: import("@oclif/parser/lib/flags").IOptionFlag<string>;
export declare const listrRenderer: import("@oclif/parser/lib/flags").IOptionFlag<string>;
export declare const accessToken: import("@oclif/parser/lib/flags").IOptionFlag<string | undefined>;

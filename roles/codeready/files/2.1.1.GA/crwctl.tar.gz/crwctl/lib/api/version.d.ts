/*********************************************************************
 * Copyright (c) 2020 Red Hat, Inc.
 *
 * This program and the accompanying materials are made
 * available under the terms of the Eclipse Public License 2.0
 * which is available at https://www.eclipse.org/legal/epl-2.0/
 *
 * SPDX-License-Identifier: EPL-2.0
 **********************************************************************/
import Listr = require('listr');
export declare namespace VersionHelper {
    const MINIMAL_OPENSHIFT_VERSION = "3.11";
    const MINIMAL_K8S_VERSION = "1.9";
    const MINIMAL_HELM_VERSION = "2.15";
    function getOpenShiftCheckVersionTask(flags: any): Listr.ListrTask;
    function getK8sCheckVersionTask(flags: any): Listr.ListrTask;
    function getOpenShiftVersion(): Promise<string | undefined>;
    function getK8sVersionWithOC(): Promise<string | undefined>;
    function getK8sVersionWithKubectl(): Promise<string | undefined>;
    function checkMinimalK8sVersion(actualVersion: string): boolean;
    function checkMinimalOpenShiftVersion(actualVersion: string): boolean;
    function checkMinimalHelmVersion(actualVersion: string): boolean;
    /**
     * Compare versions and return true if actual version is greater or equal to minimal.
     * The comparison will be done by major and minor versions.
     */
    function checkMinimalVersion(actual: string, minimal: string): boolean;
    function getError(actualVersion: string, minimalVersion: string, component: string): Error;
}
